const { getDB, connectDB } = require("../config/db");
const { ObjectId } = require("mongodb");
const { itineraries } = require("../constants/collections");

const createItinerary = async (req, res) => {
  try {
    const db = await connectDB();
    const tripData = req.body;

    const result = await db.collection(itineraries).insertOne({
      ...tripData,
      status: "saved",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    res.status(201).send({ success: true, insertedId: result.insertedId });
  } catch (error) {
    console.error("Database Error:", error);
    res.status(500).send({ message: "Internal Server Error" });
  }
};

const getUserItineraries = async (req, res) => {
  try {
    const { email } = req.params;
    const db = await connectDB();

    if (!email) {
      return res.status(400).send({ message: "User email is required" });
    }

    const result = await db
      .collection(itineraries)
      .find({ userEmail: email })
      .sort({ createdAt: -1 })
      .toArray();

    res.status(200).send(result);
  } catch (error) {
    console.error("Fetch Error:", error);
    res.status(500).send({ message: "Failed to fetch your trips" });
  }
};

const getSingleItinerary = async (req, res) => {
  try {
    const { id } = req.params;
    const db = await connectDB();
    const result = await db.collection("itineraries").findOne({ _id: new ObjectId(id) });

    if (!result) return res.status(404).send({ message: "Not found" });
    res.send(result);
  } catch (error) {
    res.status(500).send({ message: "Error fetching itinerary" });
  }
};

const deleteItinerary = async (req, res) => {
  try {
    const db = await connectDB();
    const { id } = req.params;

    if (!ObjectId.isValid(id)) {
      return res.status(400).send({
        success: false,
        message: "Invalid itinerary ID",
      });
    }

    const result = await db
      .collection("itineraries")
      .deleteOne({ _id: new ObjectId(id) });

    if (result.deletedCount === 0) {
      return res.status(404).send({
        success: false,
        message: "Itinerary not found",
      });
    }

    res.send({
      success: true,
      message: "Itinerary deleted successfully",
    });
  } catch (error) {
    console.error("Delete Error:", error);
    res.status(500).send({
      success: false,
      message: "Internal Server Error",
    });
  }
};

const deleteActivity = async (req, res) => {
  try {
    const db = await connectDB();
    const { itineraryId, activityId } = req.params;

    if (!ObjectId.isValid(itineraryId)) {
      return res.status(400).send({ success: false, message: "Invalid Itinerary ID format" });
    }

    const result = await db.collection(itineraries).updateOne(
      { _id: new ObjectId(itineraryId) },
      {
        $pull: {
          "days.$[].activities": {
            id: Number(activityId),
          },
        },
      },
    );

    if (result.modifiedCount === 0) {
      return res.status(404).send({ success: false, message: "No activity found to delete" });
    }

    res.send({ success: true });
  } catch (error) {
    console.error("Delete Activity Error:", error);
    res.status(500).send({ success: false, message: "Internal Server Error" });
  }
};

const updateItinerary = async (req, res) => {
  try {
    const db = await connectDB();
    const { id } = req.params;
    const updateData = req.body;

    if (!ObjectId.isValid(id)) {
      return res.status(400).send({ success: false, message: "Invalid ID" });
    }

    const result = await db
      .collection("itineraries")
      .updateOne(
        { _id: new ObjectId(id) },
        { $set: { ...updateData, updatedAt: new Date() } },
      );

    res.send({ success: true, message: "Updated successfully" });
  } catch (error) {
    res.status(500).send({ success: false, message: "Internal Server Error" });
  }
};


module.exports = {
  createItinerary,
  getUserItineraries,
  getSingleItinerary,
  deleteItinerary,
  deleteActivity,
  updateItinerary,
};